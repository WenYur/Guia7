package com.cursosena.VeciCocina;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VeciCocinaApplicationTests {

	@Test
	void contextLoads() {
	}

}
